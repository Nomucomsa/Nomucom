-- Nomucom database schema
-- Run this in the Supabase SQL editor (or via `supabase db push`) once
-- your project is created.
--
-- NOTE: services/coaches/programs are still static data in src/lib/data.ts
-- at this stage (matched by `slug`). Migrating them into their own tables
-- is a natural next step once the admin dashboard needs to edit them -
-- the `service_slug` columns below are written to make that migration
-- straightforward later (swap the text column for a foreign key).

create extension if not exists "uuid-ossp";

-- ========== Bookings ==========
create table if not exists bookings (
  id uuid primary key default uuid_generate_v4(),
  service_slug text not null,
  full_name text not null,
  phone text not null,
  email text not null,
  preferred_date date,
  preferred_time time,
  notes text,
  amount numeric not null,
  payment_status text not null default 'pending_payment'
    check (payment_status in ('pending_payment','payment_submitted','payment_verified','rejected')),
  booking_status text not null default 'pending_payment'
    check (booking_status in ('pending_payment','payment_submitted','payment_verified','booking_confirmed','completed','cancelled','rejected')),
  created_at timestamptz not null default now()
);

-- ========== Payment proofs ==========
create table if not exists payment_proofs (
  id uuid primary key default uuid_generate_v4(),
  booking_id uuid not null references bookings(id) on delete cascade,
  payer_name text not null,
  transaction_ref text,
  transfer_date date,
  amount numeric not null,
  file_url text not null,
  uploaded_at timestamptz not null default now()
);

-- ========== Bank account (single editable row shown at checkout) ==========
create table if not exists bank_account (
  id int primary key default 1,
  bank_name text,
  account_holder text default 'نموكم',
  account_number text,
  iban text,
  updated_at timestamptz not null default now(),
  constraint single_row check (id = 1)
);
insert into bank_account (id) values (1) on conflict (id) do nothing;

-- ========== Community members (from the "join community" form) ==========
create table if not exists community_members (
  id uuid primary key default uuid_generate_v4(),
  full_name text not null,
  phone text,
  email text,
  interests text[],
  created_at timestamptz not null default now()
);

-- ========== Admin users ==========
-- Uses Supabase Auth's built-in users table for login; this table just
-- flags which auth users are allowed into /admin.
create table if not exists admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text default 'admin'
);

-- ========== Row Level Security ==========
alter table bookings enable row level security;
alter table payment_proofs enable row level security;
alter table bank_account enable row level security;
alter table community_members enable row level security;
alter table admin_users enable row level security;

-- Public (anon) can INSERT a booking, but only ever with the starting status.
create policy "public can create pending bookings"
  on bookings for insert
  to anon
  with check (payment_status = 'pending_payment' and booking_status = 'pending_payment');

-- Public can insert their own payment proof.
create policy "public can submit payment proofs"
  on payment_proofs for insert
  to anon
  with check (true);

-- Public can read the bank account details (needed at checkout).
create policy "public can read bank account"
  on bank_account for select
  to anon
  using (true);

-- Public can join the community.
create policy "public can join community"
  on community_members for insert
  to anon
  with check (true);

-- Everything else (reading bookings, updating statuses, editing bank
-- account, managing admin_users) is restricted to authenticated admins -
-- add policies here once the admin dashboard (Phase 8) is wired up, e.g.:
--
-- create policy "admins can read all bookings"
--   on bookings for select
--   to authenticated
--   using (exists (select 1 from admin_users where user_id = auth.uid()));
