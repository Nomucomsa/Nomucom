import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        navy: "#1E3A5F",
        blue: "#3D6D9E",
        sky: "#EAF2F8",
        green: "#4C6B3F",
        leaf: "#8FAE78",
        cream: "#FAF6F0",
        ink: "#22303F",
        muted: "#6B7A85",
      },
      fontFamily: {
        heading: ["var(--font-cairo)", "sans-serif"],
        body: ["var(--font-tajawal)", "sans-serif"],
      },
      borderRadius: {
        xl2: "20px",
      },
      boxShadow: {
        soft: "0 12px 30px -12px rgba(30,58,95,0.18)",
      },
    },
  },
  plugins: [],
};

export default config;
