"use server";

import { createClient } from "@supabase/supabase-js";
import { BookingInput, PaymentProofInput } from "@/types";
import { getServiceBySlug } from "@/lib/data";

// Server-side client using the anon key is fine here because RLS policies
// (see supabase/schema.sql) restrict what an anonymous insert can do -
// e.g. a booking can only be created with status 'pending_payment'.
function getServerClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}

export async function createBooking(input: BookingInput) {
  const service = getServiceBySlug(input.serviceSlug);
  if (!service) {
    return { error: "الخدمة غير موجودة" };
  }

  const supabase = getServerClient();

  const { data, error } = await supabase
    .from("bookings")
    .insert({
      service_slug: input.serviceSlug,
      full_name: input.fullName,
      phone: input.phone,
      email: input.email,
      preferred_date: input.preferredDate,
      preferred_time: input.preferredTime,
      notes: input.notes ?? null,
      amount: service.price,
      payment_status: "pending_payment",
      booking_status: "pending_payment",
    })
    .select("id")
    .single();

  if (error) {
    console.error(error);
    return { error: "تعذر إنشاء الحجز، حاول مرة أخرى" };
  }

  return { bookingId: data.id as string };
}

export async function submitPaymentProof(input: PaymentProofInput) {
  const supabase = getServerClient();

  const { error } = await supabase.from("payment_proofs").insert({
    booking_id: input.bookingId,
    payer_name: input.payerName,
    transaction_ref: input.transactionRef,
    transfer_date: input.transferDate,
    amount: input.amount,
    file_url: input.fileUrl,
  });

  if (error) {
    console.error(error);
    return { error: "تعذر إرسال إثبات التحويل" };
  }

  // Move the booking forward in the workflow - an admin still has to verify
  // the actual transfer before it becomes "payment_verified".
  await supabase
    .from("bookings")
    .update({ payment_status: "payment_submitted" })
    .eq("id", input.bookingId);

  return { success: true };
}

export async function joinCommunity(input: {
  fullName: string;
  phone: string;
  email: string;
  interests: string[];
}) {
  const supabase = getServerClient();

  const { error } = await supabase.from("community_members").insert({
    full_name: input.fullName,
    phone: input.phone,
    email: input.email,
    interests: input.interests,
  });

  if (error) {
    console.error(error);
    return { error: "تعذر إتمام الانضمام، حاول مرة أخرى" };
  }

  return { success: true };
}

export async function uploadPaymentProofFile(file: File, bookingId: string) {
  const supabase = getServerClient();
  const path = `${bookingId}/${Date.now()}-${file.name}`;

  const { error } = await supabase.storage
    .from("payment-proofs")
    .upload(path, file);

  if (error) {
    console.error(error);
    return { error: "تعذر رفع الملف" };
  }

  const { data } = supabase.storage.from("payment-proofs").getPublicUrl(path);
  return { fileUrl: data.publicUrl };
}
