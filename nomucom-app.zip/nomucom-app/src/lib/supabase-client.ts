import { createClient } from "@supabase/supabase-js";

// Client-side Supabase instance - safe to use in the browser.
// Uses the public anon key, which is restricted by Row Level Security
// policies defined in supabase/schema.sql.
export const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);
