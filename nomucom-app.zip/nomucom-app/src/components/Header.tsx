import Image from "next/image";
import Link from "next/link";

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-cream/90 backdrop-blur-md shadow-[0_4px_20px_-10px_rgba(30,58,95,0.15)]">
      <div className="section-wrap flex items-center justify-between py-3.5">
        <Link href="/" className="flex items-center gap-2.5 font-heading font-extrabold text-lg text-navy">
          <Image src="/logo-icon.png" alt="شعار نموكم" width={36} height={36} />
          نموكم
        </Link>

        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-navy">
          <Link href="/#services">خدماتنا</Link>
          <Link href="/#programs">برامجنا</Link>
          <Link href="/#team">فريقنا</Link>
          <Link href="/#community">مجتمع نموكم</Link>
          <Link href="/about">عن نموكم</Link>
        </nav>

        <Link href="/#services" className="btn-primary py-2.5 px-5 text-sm">
          احجز الآن
        </Link>
      </div>
    </header>
  );
}
