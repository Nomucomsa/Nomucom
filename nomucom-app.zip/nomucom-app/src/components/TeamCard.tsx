import Image from "next/image";
import Link from "next/link";
import { Coach } from "@/types";

export default function TeamCard({ coach }: { coach: Coach }) {
  return (
    <div className="card p-8 grid grid-cols-[1fr_110px] gap-5 items-start">
      <div>
        <h3 className="font-heading text-xl text-navy mb-1">
          <Link href={`/team/${coach.slug}`}>{coach.name}</Link>
        </h3>
        <p className="text-blue font-semibold text-sm mb-4">{coach.role}</p>

        <div className="bg-white rounded-2xl p-4 mb-4 border border-slate-100">
          <div className="font-bold text-navy text-sm mb-2.5">نبذة عن الأخصائي</div>
          <ul>
            {coach.bio.slice(0, 3).map((line) => (
              <li key={line} className="text-sm text-muted py-1.5 border-b border-dashed border-slate-100 last:border-none">
                {line}
              </li>
            ))}
          </ul>
        </div>

        <div className="relative bg-white rounded-2xl p-5 shadow-soft text-sm">
          <span className="absolute -top-3.5 right-5 w-7 h-7 rounded-full bg-blue text-white flex items-center justify-center font-heading font-extrabold text-base">
            &rdquo;
          </span>
          {coach.quote}
        </div>

        <Link href={`/team/${coach.slug}`} className="inline-block mt-4 font-bold text-navy text-sm border-b-2 border-green">
          احجز جلسة ←
        </Link>
      </div>

      <div className="w-[110px] h-[110px] rounded-full overflow-hidden border-2 border-blue">
        <Image src={coach.photo} alt={coach.name} width={110} height={110} className="object-cover w-full h-full" />
      </div>
    </div>
  );
}
