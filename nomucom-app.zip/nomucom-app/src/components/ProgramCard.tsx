import Link from "next/link";
import { Service } from "@/types";

export default function ProgramCard({
  program,
  variant = "navy",
}: {
  program: Service;
  variant?: "navy" | "green";
}) {
  const bg =
    variant === "navy"
      ? "bg-gradient-to-br from-navy to-[#14293f]"
      : "bg-gradient-to-br from-green to-[#33472a]";

  return (
    <div className={`relative overflow-hidden rounded-[26px] p-9 text-white min-h-[340px] flex flex-col ${bg}`}>
      <span className="self-start text-xs font-bold bg-white/15 px-4 py-1.5 rounded-full mb-5">
        {program.category.includes("شمولاً") ? "الأكثر شمولاً" : "رحلة متكاملة"}
      </span>
      <h3 className="font-heading text-white text-2xl mb-3.5">{program.title}</h3>
      <p className="text-white/85 text-sm mb-6">{program.description}</p>
      <div className="mt-auto flex items-center justify-between">
        <span className="font-heading font-extrabold text-xl">
          {program.price} <span className="text-xs font-normal opacity-80">ريال · {program.sessionsCount} جلسات</span>
        </span>
        <Link
          href={`/services/${program.slug}`}
          className="btn py-2 px-5 text-sm"
          style={{ background: "white", color: variant === "navy" ? "#1E3A5F" : "#4C6B3F" }}
        >
          ابدأ الرحلة
        </Link>
      </div>
    </div>
  );
}
