import Image from "next/image";
import Link from "next/link";

export default function Footer() {
  return (
    <footer className="bg-[#F1EAE0] pt-10 pb-6 mt-10">
      <div className="section-wrap">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">
          <div>
            <div className="flex items-center gap-2.5 font-heading font-extrabold text-lg text-navy mb-2">
              <Image src="/logo-icon.png" alt="شعار نموكم" width={34} height={34} />
              نموكم
            </div>
            <p className="text-sm text-muted max-w-[240px]">رحلتك تبدأ من هنا.</p>
            <div className="flex gap-3 mt-4">
              <a
                href="https://www.instagram.com/nomucom.sa"
                target="_blank"
                rel="noopener"
                aria-label="Instagram"
                className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-navy text-xs font-bold shadow"
              >
                IG
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-heading text-navy text-sm mb-3">روابط الموقع</h4>
            <ul className="space-y-2 text-sm text-muted">
              <li><Link href="/#services">الخدمات</Link></li>
              <li><Link href="/#programs">البرامج</Link></li>
              <li><Link href="/#team">فريقنا</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-heading text-navy text-sm mb-3">عن نموكم</h4>
            <ul className="space-y-2 text-sm text-muted">
              <li><Link href="/about">من نحن</Link></li>
              <li><Link href="/#community">مجتمع نموكم</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-heading text-navy text-sm mb-3">قانوني</h4>
            <ul className="space-y-2 text-sm text-muted">
              <li><Link href="/privacy">الخصوصية</Link></li>
              <li><Link href="/terms">الشروط والأحكام</Link></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-[#E3D9C8] pt-5 text-center text-xs text-muted">
          © 2026 نموكم NOMUCOM. جميع الحقوق محفوظة.
        </div>
      </div>
    </footer>
  );
}
