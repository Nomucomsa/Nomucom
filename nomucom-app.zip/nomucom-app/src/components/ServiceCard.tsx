import Link from "next/link";
import { Service } from "@/types";

const accentByCategory: Record<string, string> = {
  "كوتشينج فردي": "border-blue",
  "كوتشينج جماعي": "border-green",
  "جلسة حوارية": "border-leaf",
  "دعم جماعي": "border-muted",
};

export default function ServiceCard({ service }: { service: Service }) {
  const accent = accentByCategory[service.category] ?? "border-blue";

  return (
    <div className={`card border-t-4 ${accent} p-7 flex flex-col gap-3.5 hover:-translate-y-1.5 transition-transform`}>
      <span className="self-start text-xs font-bold text-blue bg-sky px-3 py-1 rounded-full">
        {service.category}
      </span>
      <h3 className="font-heading text-lg text-navy">{service.title}</h3>
      <p className="text-sm text-muted">{service.description}</p>
      <div className="mt-auto pt-3 border-t border-dashed border-slate-200 flex items-center justify-between">
        <span className="font-heading font-extrabold text-xl text-navy">
          {service.price} <span className="text-xs font-medium text-muted">ريال</span>
        </span>
        <Link href={`/services/${service.slug}`} className="btn-primary py-2 px-5 text-sm">
          احجز الآن
        </Link>
      </div>
    </div>
  );
}
