export type Coach = {
  slug: string;
  name: string;
  role: string;
  photo: string;
  quote: string;
  bio: string[];
};

export type ServiceType = "session" | "package";

export type Service = {
  slug: string;
  category: string;
  title: string;
  price: number;
  type: string;
  description: string;
  whatYouGet: string[];
  whoItsFor: string;
  coachSlug?: string;
  serviceType: ServiceType;
  sessionsCount?: number;
};

export type BookingStatus =
  | "pending_payment"
  | "payment_submitted"
  | "payment_verified"
  | "booking_confirmed"
  | "completed"
  | "cancelled"
  | "rejected";

export type BookingInput = {
  serviceSlug: string;
  fullName: string;
  phone: string;
  email: string;
  preferredDate: string;
  preferredTime: string;
  notes?: string;
};

export type PaymentProofInput = {
  bookingId: string;
  payerName: string;
  transactionRef: string;
  transferDate: string;
  amount: number;
  fileUrl: string;
};
