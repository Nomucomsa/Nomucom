"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Service } from "@/types";
import { createBooking, submitPaymentProof, uploadPaymentProofFile } from "@/lib/actions";

const steps = ["بيانات الحجز", "التحويل البنكي", "إثبات التحويل", "التأكيد"];

export default function BookingFlow({ service }: { service: Service }) {
  const [step, setStep] = useState(1);
  const [bookingId, setBookingId] = useState<string | null>(null);
  const [orderNo, setOrderNo] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    email: "",
    preferredDate: "",
    preferredTime: "",
    notes: "",
  });

  const [proof, setProof] = useState({
    payerName: "",
    transactionRef: "",
    transferDate: "",
    file: null as File | null,
  });

  async function handleStep1Submit() {
    setSubmitting(true);
    setErrorMsg(null);
    const result = await createBooking({
      serviceSlug: service.slug,
      ...form,
    });
    setSubmitting(false);
    if ("error" in result && result.error) {
      setErrorMsg(result.error);
      return;
    }
    setBookingId(result.bookingId!);
    setStep(2);
  }

  async function handleFinalSubmit() {
    if (!bookingId) return;
    setSubmitting(true);
    setErrorMsg(null);

    let fileUrl = "";
    if (proof.file) {
      const uploadResult = await uploadPaymentProofFile(proof.file, bookingId);
      if ("error" in uploadResult && uploadResult.error) {
        setSubmitting(false);
        setErrorMsg(uploadResult.error);
        return;
      }
      fileUrl = uploadResult.fileUrl!;
    }

    const result = await submitPaymentProof({
      bookingId,
      payerName: proof.payerName,
      transactionRef: proof.transactionRef,
      transferDate: proof.transferDate,
      amount: service.price,
      fileUrl,
    });

    setSubmitting(false);
    if ("error" in result && result.error) {
      setErrorMsg(result.error);
      return;
    }

    setOrderNo("#NMC-" + bookingId!.slice(0, 8).toUpperCase());
    setStep(4);
  }

  return (
    <div className="min-h-screen bg-cream">
      <header className="bg-cream/95 backdrop-blur-md shadow-sm py-3.5">
        <div className="max-w-[640px] mx-auto px-5 flex items-center gap-2.5">
          <Link href="/" className="flex items-center gap-2.5 font-heading font-extrabold text-lg text-navy">
            <Image src="/logo-icon.png" alt="شعار نموكم" width={34} height={34} />
            نموكم
          </Link>
        </div>
      </header>

      <div className="max-w-[640px] mx-auto px-5 py-10 pb-20">
        {/* progress */}
        <div className="flex justify-between mb-11 relative">
          <div className="absolute top-4 inset-x-[6%] h-0.5 bg-[#E1DACB] -z-10" />
          {steps.map((label, i) => {
            const n = i + 1;
            const active = n === step;
            const done = n < step;
            return (
              <div key={label} className="flex flex-col items-center gap-2 flex-1">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center font-heading font-bold text-sm border-2 ${
                    active
                      ? "bg-navy border-navy text-white"
                      : done
                      ? "bg-green border-green text-white"
                      : "bg-white border-[#D8CFBC] text-muted"
                  }`}
                >
                  {n}
                </div>
                <div className={`text-xs font-semibold text-center ${active ? "text-navy" : "text-muted"}`}>
                  {label}
                </div>
              </div>
            );
          })}
        </div>

        {errorMsg && (
          <div className="bg-red-50 text-red-700 text-sm rounded-xl p-4 mb-5">{errorMsg}</div>
        )}

        {step === 1 && (
          <div className="card p-8">
            <h2 className="font-heading text-xl text-navy mb-1.5">بيانات الحجز</h2>
            <p className="text-sm text-muted mb-6">
              {service.title} — {service.price} ريال
            </p>

            <Field label="الاسم الكامل">
              <input
                value={form.fullName}
                onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                placeholder="مثال: عبدالعزيز الحناوي"
              />
            </Field>
            <div className="grid grid-cols-2 gap-3.5">
              <Field label="رقم الجوال">
                <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="05xxxxxxxx" />
              </Field>
              <Field label="البريد الإلكتروني">
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="example@email.com"
                />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3.5">
              <Field label="التاريخ المفضل">
                <input type="date" value={form.preferredDate} onChange={(e) => setForm({ ...form, preferredDate: e.target.value })} />
              </Field>
              <Field label="الوقت المفضل">
                <input type="time" value={form.preferredTime} onChange={(e) => setForm({ ...form, preferredTime: e.target.value })} />
              </Field>
            </div>
            <Field label="ملاحظات إضافية (اختياري)">
              <textarea
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                placeholder="أي تفاصيل تحب تشاركها قبل الجلسة"
                rows={3}
              />
            </Field>

            <button disabled={submitting} onClick={handleStep1Submit} className="btn-primary w-full mt-2">
              {submitting ? "جارٍ الحفظ..." : "متابعة الدفع"}
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="card p-8">
            <h2 className="font-heading text-xl text-navy mb-1.5">خطوة الدفع</h2>
            <p className="text-sm text-muted mb-6">
              لإتمام حجزك، يرجى تحويل قيمة الخدمة إلى الحساب البنكي الموضح أدناه.
            </p>

            <div className="text-center mb-6">
              <div className="font-heading font-extrabold text-3xl text-navy">{service.price} ريال</div>
              <div className="text-xs text-muted">المبلغ المطلوب تحويله</div>
            </div>

            <div className="bg-sky rounded-2xl p-5 mb-6 space-y-1">
              <BankRow k="اسم البنك" v="سيتم إضافته لاحقًا" />
              <BankRow k="اسم صاحب الحساب" v="نموكم" />
              <BankRow k="رقم الحساب" v="سيتم إضافته لاحقًا" />
              <BankRow k="IBAN" v="سيتم إضافة IBAN لاحقًا" />
            </div>

            <div className="flex gap-3">
              <button onClick={() => setStep(1)} className="btn-ghost flex-1 text-center">رجوع</button>
              <button onClick={() => setStep(3)} className="btn-primary flex-1 text-center">تم التحويل، متابعة</button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="card p-8">
            <h2 className="font-heading text-xl text-navy mb-1.5">إثبات التحويل</h2>
            <p className="text-sm text-muted mb-6">ارفع إثبات التحويل حتى يراجعه فريقنا ويؤكد حجزك.</p>

            <div className="grid grid-cols-2 gap-3.5">
              <Field label="اسم المحوّل">
                <input value={proof.payerName} onChange={(e) => setProof({ ...proof, payerName: e.target.value })} />
              </Field>
              <Field label="رقم العملية / المرجع">
                <input value={proof.transactionRef} onChange={(e) => setProof({ ...proof, transactionRef: e.target.value })} />
              </Field>
            </div>
            <Field label="تاريخ التحويل">
              <input type="date" value={proof.transferDate} onChange={(e) => setProof({ ...proof, transferDate: e.target.value })} />
            </Field>
            <Field label="إرفاق إثبات التحويل">
              <input
                type="file"
                accept="image/*,.pdf"
                onChange={(e) => setProof({ ...proof, file: e.target.files?.[0] ?? null })}
              />
            </Field>

            <div className="flex gap-3 mt-2">
              <button onClick={() => setStep(2)} className="btn-ghost flex-1 text-center">رجوع</button>
              <button disabled={submitting} onClick={handleFinalSubmit} className="btn-primary flex-1 text-center">
                {submitting ? "جارٍ الإرسال..." : "إرسال طلب الحجز"}
              </button>
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="card p-8 text-center">
            <div className="w-[70px] h-[70px] rounded-full bg-[#EAF3E8] flex items-center justify-center mx-auto mb-5">
              ✓
            </div>
            <h2 className="font-heading text-xl text-navy mb-1.5">تم استلام طلبك بنجاح</h2>
            <p className="text-sm text-muted mb-7">
              شكراً لاختيارك نموكم 🌱
              <br />
              سيتم مراجعة التحويل وتأكيد حجزك من فريق نموكم.
            </p>
            <div className="bg-sky rounded-2xl p-5 mb-6 text-sm space-y-1.5 text-right">
              <div className="flex justify-between"><span>رقم الطلب</span><b>{orderNo}</b></div>
              <div className="flex justify-between"><span>الخدمة</span><b>{service.title}</b></div>
              <div className="flex justify-between"><span>المبلغ</span><b>{service.price} ريال</b></div>
              <div className="flex justify-between items-center">
                <span>حالة الطلب</span>
                <span className="bg-[#FCEFD6] text-[#8A6A1E] font-bold text-xs px-3.5 py-1.5 rounded-full">
                  بانتظار التحقق من الدفع
                </span>
              </div>
            </div>
            <Link href="/" className="btn-primary block">العودة للصفحة الرئيسية</Link>
          </div>
        )}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mb-4.5">
      <label className="block text-sm font-semibold text-navy mb-1.5">{label}</label>
      <div className="[&_input]:w-full [&_input]:rounded-xl [&_input]:border [&_input]:border-slate-200 [&_input]:px-3.5 [&_input]:py-3 [&_input]:text-sm [&_textarea]:w-full [&_textarea]:rounded-xl [&_textarea]:border [&_textarea]:border-slate-200 [&_textarea]:px-3.5 [&_textarea]:py-3 [&_textarea]:text-sm">
        {children}
      </div>
    </div>
  );
}

function BankRow({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between items-center py-2.5 border-b border-dashed border-[#C9DCE9] last:border-none">
      <span className="text-xs text-muted">{k}</span>
      <span className="font-bold text-navy text-sm">{v}</span>
    </div>
  );
}
