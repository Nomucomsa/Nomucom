import { getServiceBySlug } from "@/lib/data";
import { notFound } from "next/navigation";
import BookingFlow from "./BookingFlow";

export default function BookingPage({
  searchParams,
}: {
  searchParams: { service?: string };
}) {
  const service = getServiceBySlug(searchParams.service ?? "");
  if (!service) return notFound();

  return <BookingFlow service={service} />;
}
