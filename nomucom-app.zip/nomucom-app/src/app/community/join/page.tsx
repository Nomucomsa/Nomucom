"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { joinCommunity } from "@/lib/actions";

const interestOptions = ["الجلسات الجماعية", "الجلسات الحوارية", "الدعم الجماعي", "الفعاليات وورش العمل"];

export default function CommunityJoinPage() {
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [form, setForm] = useState({ fullName: "", phone: "", email: "" });
  const [interests, setInterests] = useState<string[]>([]);

  function toggleInterest(val: string) {
    setInterests((prev) => (prev.includes(val) ? prev.filter((i) => i !== val) : [...prev, val]));
  }

  async function handleSubmit() {
    setSubmitting(true);
    setErrorMsg(null);
    const result = await joinCommunity({ ...form, interests });
    setSubmitting(false);
    if ("error" in result && result.error) {
      setErrorMsg(result.error);
      return;
    }
    setSubmitted(true);
  }

  return (
    <div className="min-h-screen bg-cream">
      <header className="bg-cream/95 backdrop-blur-md shadow-sm py-3.5">
        <div className="max-w-[560px] mx-auto px-5 flex items-center gap-2.5">
          <Link href="/" className="flex items-center gap-2.5 font-heading font-extrabold text-lg text-navy">
            <Image src="/logo-icon.png" alt="شعار نموكم" width={34} height={34} />
            نموكم
          </Link>
        </div>
      </header>

      <div className="max-w-[560px] mx-auto px-5 py-12 pb-20">
        {!submitted ? (
          <>
            <div className="text-center mb-8">
              <h1 className="font-heading text-2xl md:text-3xl text-navy mb-3">انضم إلى مجتمع نموكم</h1>
              <p className="text-sm text-muted max-w-[46ch] mx-auto">
                ليست مجرد منصة.. بل مجتمع يدعمك في رحلتك. عبّي بياناتك وراح نتواصل معك بكل جديد يناسبك.
              </p>
            </div>

            {errorMsg && <div className="bg-red-50 text-red-700 text-sm rounded-xl p-4 mb-5">{errorMsg}</div>}

            <div className="card p-7">
              <div className="mb-4.5">
                <label className="block text-sm font-semibold text-navy mb-1.5">الاسم الكامل</label>
                <input
                  className="w-full rounded-xl border border-slate-200 px-3.5 py-3 text-sm"
                  value={form.fullName}
                  onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                  placeholder="اسمك"
                />
              </div>
              <div className="mb-4.5">
                <label className="block text-sm font-semibold text-navy mb-1.5">رقم الجوال</label>
                <input
                  className="w-full rounded-xl border border-slate-200 px-3.5 py-3 text-sm"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="05xxxxxxxx"
                />
              </div>
              <div className="mb-4.5">
                <label className="block text-sm font-semibold text-navy mb-1.5">البريد الإلكتروني</label>
                <input
                  type="email"
                  className="w-full rounded-xl border border-slate-200 px-3.5 py-3 text-sm"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="example@email.com"
                />
              </div>
              <div className="mb-4.5">
                <label className="block text-sm font-semibold text-navy mb-2">وش أكثر شي يهمك في مجتمع نموكم؟</label>
                <div className="grid grid-cols-2 gap-2.5">
                  {interestOptions.map((opt) => (
                    <div
                      key={opt}
                      onClick={() => toggleInterest(opt)}
                      className={`cursor-pointer rounded-xl border px-3.5 py-2.5 text-center text-sm transition-colors ${
                        interests.includes(opt)
                          ? "border-green bg-sky text-navy font-bold"
                          : "border-slate-200 text-ink"
                      }`}
                    >
                      {opt}
                    </div>
                  ))}
                </div>
              </div>
              <button disabled={submitting} onClick={handleSubmit} className="btn-primary w-full mt-2">
                {submitting ? "جارٍ الإرسال..." : "انضم الآن"}
              </button>
            </div>
          </>
        ) : (
          <div className="card p-8 text-center">
            <div className="w-[70px] h-[70px] rounded-full bg-[#EAF3E8] flex items-center justify-center mx-auto mb-5">
              ✓
            </div>
            <h2 className="font-heading text-xl text-navy mb-1.5">تم الانضمام لمجتمع نموكم 🌱</h2>
            <p className="text-sm text-muted mb-6">أهلاً بك معنا! رحلتك نحو التغيير تبدأ من هنا.</p>
            <div className="bg-sky rounded-2xl p-5 text-sm mb-6">
              <b className="text-navy">الخطوة التالية:</b> راح يتواصل معك فريق نموكم قريبًا بكل التفاصيل عن الجلسات والفعاليات المناسبة لاهتمامك.
            </div>
            <a
              href="https://www.instagram.com/nomucom.sa"
              target="_blank"
              rel="noopener"
              className="btn w-full block mb-2.5"
              style={{ background: "#EAF2F8", color: "#1E3A5F" }}
            >
              تابعنا على انستقرام
            </a>
            <Link href="/" className="btn-primary w-full block">العودة للصفحة الرئيسية</Link>
          </div>
        )}
      </div>
    </div>
  );
}
