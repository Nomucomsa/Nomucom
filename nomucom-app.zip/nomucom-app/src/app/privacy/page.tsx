import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata = { title: "سياسة الخصوصية | نموكم" };

export default function PrivacyPage() {
  return (
    <>
      <Header />
      <div className="section-wrap py-20 max-w-[70ch]">
        <h1 className="font-heading text-3xl text-navy mb-6">سياسة الخصوصية</h1>
        <p className="text-sm text-muted">
          محتوى هذه الصفحة نص مبدئي (placeholder) - يحتاج فريق نموكم لصياغة سياسة
          الخصوصية الفعلية قبل الإطلاق، توضح كيفية جمع بيانات الحجز والدفع
          وحمايتها والتعامل معها.
        </p>
      </div>
      <Footer />
    </>
  );
}
