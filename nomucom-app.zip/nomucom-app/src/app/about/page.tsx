import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import TeamCard from "@/components/TeamCard";
import { coaches } from "@/lib/data";

export const metadata = { title: "عن نموكم | NOMUCOM" };

export default function AboutPage() {
  return (
    <>
      <Header />

      <div className="section-wrap pt-6 text-sm text-muted">
        <Link href="/" className="text-blue font-semibold">الرئيسية</Link>
        <span className="mx-1.5 opacity-60">/</span>
        <span>عن نموكم</span>
      </div>

      <div className="section-wrap">
        <div className="bg-gradient-to-b from-sky to-cream rounded-[28px] mt-6 py-16 text-center max-w-[760px] mx-auto px-6">
          <h1 className="font-heading text-3xl md:text-4xl text-navy mb-7">من نحن؟</h1>
          <p className="text-lg leading-loose mb-5">
            نموكم منصة ومجتمع للنمو الشخصي، تجمع بين الكوتشينج، التمكين المهني، وجودة الحياة، لنرافق الإنسان في رحلة متكاملة نحو حياة أكثر وعيًا وتوازنًا وأثرًا.
          </p>
          <p className="text-lg leading-loose">
            نؤمن بأن النجاح الحقيقي يبدأ من الداخل؛ عندما يفهم الإنسان ذاته، ويكتشف إمكاناته، ويعتني بصحته وجودة حياته، يصبح أكثر قدرة على بناء مستقبل ينسجم مع قيمه وطموحاته.
          </p>
        </div>
      </div>

      <section className="py-20">
        <div className="section-wrap">
          <div className="text-center max-w-[600px] mx-auto mb-11">
            <h2 className="font-heading text-2xl md:text-3xl text-navy">رسالتنا ورؤيتنا</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="card p-8">
              <h3 className="font-heading text-lg text-navy mb-3">رسالتنا</h3>
              <p className="text-sm">
                نرافق الأفراد في رحلة متكاملة تجمع بين الكوتشينج والتمكين المهني وجودة الحياة، عبر جلسات وبرامج تُبنى على احتياج كل شخص، ضمن مجتمع يدعمه في كل خطوة.
              </p>
            </div>
            <div className="card p-8">
              <h3 className="font-heading text-lg text-navy mb-3">رؤيتنا</h3>
              <p className="text-sm">
                أن يفهم كل إنسان ذاته ويكتشف إمكاناته، ليصبح أكثر قدرة على صناعة مستقبل ينسجم مع قيمه وطموحاته — بحياة أكثر وعيًا وتوازنًا وأثرًا.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-sky py-20">
        <div className="section-wrap">
          <div className="text-center max-w-[600px] mx-auto mb-11">
            <h2 className="font-heading text-2xl md:text-3xl text-navy mb-3">الشعور الذي نبنيه في كل تجربة</h2>
            <p className="text-muted text-sm">القيم التي توجّه كل جلسة وكل تفصيل في نموكم.</p>
          </div>
          <div className="flex flex-wrap gap-3.5 justify-center">
            {["الهدوء", "الثقة", "النمو", "الإنسانية", "الاحتراف", "الأمل"].map((v) => (
              <div key={v} className="bg-white rounded-2xl px-6 py-5 shadow-soft flex items-center gap-3 font-bold text-navy text-sm min-w-[150px]">
                <span className="w-2.5 h-2.5 rounded-full bg-green" />
                {v}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="section-wrap">
          <div className="text-center max-w-[600px] mx-auto mb-11">
            <h2 className="font-heading text-2xl md:text-3xl text-navy mb-3">تعرف على فريقنا</h2>
            <p className="text-muted text-sm">كوتشات معتمدون يرافقونك في رحلتك خطوة بخطوة.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {coaches.map((c) => (
              <TeamCard key={c.slug} coach={c} />
            ))}
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-br from-navy to-[#142a42] text-white text-center py-20">
        <div className="section-wrap">
          <h2 className="font-heading text-white text-2xl md:text-3xl mb-4">
            أنت تستحق أن تعيش الحياة التي تحلم بها
          </h2>
          <Link href="/#services" className="btn bg-white text-navy">استكشف خدماتنا</Link>
        </div>
      </section>

      <Footer />
    </>
  );
}
