import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { coaches, getCoachBySlug, getServicesByCoach } from "@/lib/data";

export function generateStaticParams() {
  return coaches.map((c) => ({ slug: c.slug }));
}

export default function TeamDetailPage({ params }: { params: { slug: string } }) {
  const coach = getCoachBySlug(params.slug);
  if (!coach) return notFound();

  const coachServices = getServicesByCoach(coach.slug);

  return (
    <>
      <Header />

      <div className="section-wrap pt-6 text-sm text-muted">
        <Link href="/" className="text-blue font-semibold">الرئيسية</Link>
        <span className="mx-1.5 opacity-60">/</span>
        <Link href="/#team" className="text-blue font-semibold">فريقنا</Link>
        <span className="mx-1.5 opacity-60">/</span>
        <span>{coach.name}</span>
      </div>

      <div className="section-wrap grid grid-cols-1 md:grid-cols-[220px_1fr] gap-10 py-9 items-start text-center md:text-right">
        <div className="w-[200px] h-[200px] rounded-full overflow-hidden border-4 border-blue shadow-soft mx-auto md:mx-0">
          <Image src={coach.photo} alt={coach.name} width={200} height={200} className="object-cover w-full h-full" />
        </div>
        <div>
          <h1 className="font-heading text-3xl text-navy mb-2">{coach.name}</h1>
          <div className="text-blue font-bold text-sm mb-5">{coach.role}</div>
          <div className="relative card p-6 max-w-[56ch] mx-auto md:mx-0 text-sm">
            <span className="absolute -top-4 right-6 w-8 h-8 rounded-full bg-blue text-white flex items-center justify-center font-heading font-extrabold">
              &rdquo;
            </span>
            {coach.quote}
          </div>
        </div>
      </div>

      <div className="section-wrap py-5 grid gap-11">
        <div>
          <h2 className="font-heading text-xl text-navy mb-4">نبذة عن الأخصائي</h2>
          <ul className="grid gap-3 max-w-[70ch]">
            {coach.bio.map((line) => (
              <li key={line} className="flex items-start gap-2.5 text-sm">
                <span className="mt-1 w-2 h-2 rounded-full bg-green flex-shrink-0" />
                {line}
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="font-heading text-xl text-navy mb-4">الخدمات التي يقدمها</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {coachServices.map((svc) => (
              <div key={svc.slug} className="card p-6 flex flex-col gap-2.5">
                <h4 className="font-heading text-base text-navy">{svc.title}</h4>
                <div className="font-heading font-extrabold text-navy text-lg mt-auto">
                  {svc.price} <span className="text-xs font-medium text-muted">ريال</span>
                </div>
                <Link href={`/services/${svc.slug}`} className="btn-primary py-2 px-5 text-sm self-start">
                  التفاصيل والحجز
                </Link>
              </div>
            ))}
          </div>
        </div>
      </div>

      <section className="bg-gradient-to-br from-navy to-[#142a42] text-white text-center py-20 mt-6">
        <div className="section-wrap">
          <h2 className="font-heading text-white text-2xl md:text-3xl mb-4">
            ابدأ رحلتك مع {coach.name}
          </h2>
          {coachServices[0] && (
            <Link href={`/services/${coachServices[0].slug}`} className="btn bg-white text-navy">
              احجز جلسة الآن
            </Link>
          )}
        </div>
      </section>

      <Footer />
    </>
  );
}
