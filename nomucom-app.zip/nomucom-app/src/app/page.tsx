import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ServiceCard from "@/components/ServiceCard";
import ProgramCard from "@/components/ProgramCard";
import TeamCard from "@/components/TeamCard";
import { services, coaches } from "@/lib/data";

export default function HomePage() {
  const sessionServices = services.filter((s) => s.serviceType === "session");
  const programs = services.filter((s) => s.serviceType === "package");

  return (
    <>
      <Header />

      {/* Hero */}
      <section className="relative min-h-[80vh] flex items-center overflow-hidden bg-gradient-to-br from-[#cfe0ec] via-[#e9d9c8] to-[#f3e7d8]">
        <div className="section-wrap relative z-10 text-center max-w-[760px] mx-auto py-20">
          <h1 className="font-heading font-extrabold text-4xl md:text-5xl text-navy mb-6">
            رحلتك نحو نسخة أفضل منك تبدأ هنا
          </h1>
          <p className="text-lg text-muted max-w-[520px] mx-auto mb-10">
            نموكم مجتمع يجمع الكوتشينج والحوار والدعم الجماعي لمساعدتك على اكتشاف ذاتك، وتنمية قدراتك، وبناء حياة أكثر توازناً.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Link href="#services" className="btn-primary">استكشف خدماتنا</Link>
            <Link href="/about" className="btn-ghost">تعرف على نموكم</Link>
          </div>
        </div>
      </section>

      {/* About teaser */}
      <section id="about" className="bg-gradient-to-b from-sky to-cream py-24">
        <div className="section-wrap max-w-[760px] text-center">
          <h2 className="font-heading text-3xl md:text-4xl text-navy mb-8">من نحن؟</h2>
          <p className="text-lg leading-loose mb-5">
            نموكم منصة ومجتمع للنمو الشخصي، تجمع بين الكوتشينج، التمكين المهني، وجودة الحياة، لنرافق الإنسان في رحلة متكاملة نحو حياة أكثر وعيًا وتوازنًا وأثرًا.
          </p>
          <p className="text-lg leading-loose">
            نؤمن بأن النجاح الحقيقي يبدأ من الداخل؛ عندما يفهم الإنسان ذاته، ويكتشف إمكاناته، ويعتني بصحته وجودة حياته، يصبح أكثر قدرة على بناء مستقبل ينسجم مع قيمه وطموحاته.
          </p>
        </div>
      </section>

      {/* Services */}
      <section id="services" className="py-24">
        <div className="section-wrap">
          <div className="text-center max-w-[600px] mx-auto mb-12">
            <h2 className="font-heading text-3xl md:text-4xl text-navy mb-3">خدمات نموكم</h2>
            <p className="text-muted">اختر التجربة التي تناسب احتياجك وابدأ رحلتك مع نموكم.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {sessionServices.map((s) => (
              <ServiceCard key={s.slug} service={s} />
            ))}
          </div>
        </div>
      </section>

      {/* Programs */}
      <section id="programs" className="bg-sky py-24">
        <div className="section-wrap">
          <div className="text-center max-w-[600px] mx-auto mb-12">
            <h2 className="font-heading text-3xl md:text-4xl text-navy mb-3">برامج نموكم</h2>
            <p className="text-muted">رحلات متكاملة من عدة جلسات لأثر أعمق وأكثر استدامة.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-7">
            {programs.map((p, i) => (
              <ProgramCard key={p.slug} program={p} variant={i === 0 ? "navy" : "green"} />
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section id="team" className="py-24">
        <div className="section-wrap">
          <div className="text-center max-w-[600px] mx-auto mb-12">
            <h2 className="font-heading text-3xl md:text-4xl text-navy mb-3">فريق نموكم</h2>
            <p className="text-muted">كوتشات معتمدون يرافقونك في رحلتك خطوة بخطوة.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {coaches.map((c) => (
              <TeamCard key={c.slug} coach={c} />
            ))}
          </div>
        </div>
      </section>

      {/* Community */}
      <section id="community" className="bg-sky py-24">
        <div className="section-wrap">
          <div className="text-center max-w-[600px] mx-auto mb-12">
            <h2 className="font-heading text-3xl md:text-4xl text-navy mb-3">مجتمع نموكم</h2>
            <p className="text-muted">ليست مجرد منصة.. بل مجتمع يدعمك في رحلتك.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-5 mb-10">
            {["الجلسات الجماعية", "الجلسات الحوارية", "الدعم الجماعي", "الفعاليات وورش العمل"].map((item) => (
              <div key={item} className="card p-6 text-center">
                <h4 className="font-heading text-sm text-navy mb-1.5">{item}</h4>
              </div>
            ))}
          </div>
          <div className="text-center">
            <Link href="/community/join" className="btn-primary">انضم إلى مجتمع نموكم</Link>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="bg-gradient-to-br from-navy to-[#142a42] text-white text-center py-20">
        <div className="section-wrap">
          <h2 className="font-heading text-white text-3xl md:text-4xl mb-4">
            أنت تستحق أن تعيش الحياة التي تحلم بها
          </h2>
          <p className="text-white/80 max-w-[480px] mx-auto mb-8">
            ابدأ اليوم بخطوة واحدة نحو نسخة أوضح وأكثر توازناً منك.
          </p>
          <Link href="#services" className="btn bg-white text-navy">استكشف خدماتنا</Link>
        </div>
      </section>

      <Footer />
    </>
  );
}
