import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { services, getServiceBySlug, getCoachBySlug } from "@/lib/data";

export function generateStaticParams() {
  return services.map((s) => ({ slug: s.slug }));
}

export default function ServiceDetailPage({ params }: { params: { slug: string } }) {
  const service = getServiceBySlug(params.slug);
  if (!service) return notFound();

  const coach = service.coachSlug ? getCoachBySlug(service.coachSlug) : undefined;

  return (
    <>
      <Header />

      <div className="section-wrap pt-6 text-sm text-muted">
        <Link href="/" className="text-blue font-semibold">الرئيسية</Link>
        <span className="mx-1.5 opacity-60">/</span>
        <Link href="/#services" className="text-blue font-semibold">خدماتنا</Link>
        <span className="mx-1.5 opacity-60">/</span>
        <span>{service.title}</span>
      </div>

      <div className="section-wrap grid grid-cols-1 md:grid-cols-2 gap-11 py-7">
        <div className="rounded-3xl min-h-[300px] bg-gradient-to-br from-[#cfe0ec] via-[#e9d9c8] to-[#f3e7d8]" />

        <div>
          <span className="inline-block text-xs font-bold text-blue bg-sky px-3.5 py-1.5 rounded-full mb-4">
            {service.category}
          </span>
          <h1 className="font-heading text-3xl text-navy mb-3.5">{service.title}</h1>

          {coach && (
            <div className="flex items-center gap-2.5 mb-5">
              <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-blue">
                <Image src={coach.photo} alt={coach.name} width={40} height={40} className="object-cover w-full h-full" />
              </div>
              <div>
                <div className="font-bold text-navy text-sm">مع كوتش {coach.name}</div>
                <div className="text-xs text-muted">{coach.role}</div>
              </div>
            </div>
          )}

          <p className="mb-7 max-w-[56ch]">{service.description}</p>

          <div className="card p-7">
            <div className="font-heading font-extrabold text-3xl text-navy">
              {service.price} <span className="text-sm font-medium text-muted">ريال</span>
            </div>
            <div className="h-px bg-slate-200 my-4.5" />
            <div className="flex justify-between text-sm text-muted py-1.5">
              <span>نوع الخدمة</span><b className="text-ink font-semibold">{service.type}</b>
            </div>
            <div className="flex justify-between text-sm text-muted py-1.5">
              <span>طريقة الدفع</span><b className="text-ink font-semibold">تحويل بنكي</b>
            </div>
            <Link href={`/booking?service=${service.slug}`} className="btn-primary w-full text-center mt-4.5 block">
              ابدأ طلب الحجز
            </Link>
          </div>
        </div>
      </div>

      <div className="section-wrap py-12 grid gap-11">
        <div>
          <h2 className="font-heading text-xl text-navy mb-4">ما الذي ستحصل عليه؟</h2>
          <ul className="grid gap-3">
            {service.whatYouGet.map((item) => (
              <li key={item} className="flex items-start gap-2.5 text-sm">
                <span className="mt-1 w-2 h-2 rounded-full bg-green flex-shrink-0" />
                {item}
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="font-heading text-xl text-navy mb-4">لمن تناسب هذه الخدمة؟</h2>
          <div className="bg-sky rounded-2xl p-6 text-sm">{service.whoItsFor}</div>
        </div>
      </div>

      <Footer />
    </>
  );
}
